"""load napalm_aruba505.ArubaOS class."""

# from napalm_aruba505.ArubaOS import Aruba505Driver
from napalm_aruba505.arubaf import ArubaFDriver
__all__ = ('ArubaFDriver',)

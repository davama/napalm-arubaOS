"""load napalm_arubaoss.ArubaOS class."""

from napalm_aruba505.ArubaOS import ArubaOS505
__all__ = ('ArubaOS505',)
